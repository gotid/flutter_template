import 'package:flutter/material.dart';

class MinePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('todo')),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }
}
